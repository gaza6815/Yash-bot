# 🤖 YASH BOT — WhatsApp Bot

Bot WhatsApp multi-fitur: Games, Hiburan, Sticker, Anime, Tools, Manajemen Grup, dan Sistem Reward.
Dibangun menggunakan [@whiskeysockets/baileys](https://github.com/WhiskeySockets/Baileys) dan login via **Pairing Code** (tanpa scan QR).

## 📦 Instalasi

1. Pastikan Node.js v18+ sudah terpasang.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Atur nomor owner di `config.js` (opsional).

## ▶️ Menjalankan Bot

```bash
npm start
```

Saat pertama kali dijalankan (belum ada sesi login), bot akan otomatis masuk ke **mode Pairing Code**:

```
📱 Masukkan nomor WhatsApp bot (format: 628xxxxxxxxxx, tanpa + dan tanpa spasi):
```

1. Ketik nomor WhatsApp yang akan dijadikan bot, contoh: `6281234567890` lalu tekan Enter.
2. Tunggu beberapa detik, kode pairing 8 digit akan muncul di terminal, contoh:
   ```
   🔑 KODE PAIRING KAMU: ABCD-1234
   ```
3. Di HP yang nomornya dipakai untuk bot, buka WhatsApp:
   - **Pengaturan** → **Perangkat Tertaut** → **Tautkan Perangkat**
   - Pilih **"Tautkan dengan nomor telepon"** (bukan scan QR)
   - Masukkan kode 8 digit yang muncul di terminal
4. Setelah berhasil, bot otomatis tersambung dan sesi login disimpan di folder `session/` agar tidak perlu pairing ulang setiap restart.

> 🔁 Jika ingin login ulang dengan nomor lain, hapus folder `session/` lalu jalankan ulang `npm start`.

## 🗂️ Struktur Project

```
yash-bot/
├── index.js              # Entry point + koneksi & pairing code
├── config.js              # Konfigurasi bot (nama, prefix, owner, dll)
├── commandHandler.js      # Semua logika command & menu
├── stickerHandler.js      # Pembuatan sticker (+watermark)
├── automod.js             # Antilink & welcome/leave member
├── database.js            # Database JSON (poin, xp, setting grup)
├── gameSession.js         # State game in-memory per chat
├── staticData.js          # Data jokes, quotes, fakta, pantun, soal game
├── helpers.js             # Fungsi utilitas (calc, translate, cuaca, anime, dll)
├── data/                  # File JSON database (auto generated)
└── session/                # Sesi login WhatsApp (auto generated)
```

## 🚂 Deploy ke Railway (via GitHub, full lewat browser HP)

1. Upload semua file project ini ke repository GitHub kamu.
2. Buka [railway.app](https://railway.app), login pakai GitHub.
3. **New Project** → **Deploy from GitHub repo** → pilih repo bot kamu.
4. Setelah project terbuat, masuk ke tab **Variables**, tambahkan environment variable:
   - **Key**: `PHONE_NUMBER`
   - **Value**: nomor WhatsApp bot, contoh `6281234567890` (tanpa + dan tanpa spasi)
5. Klik **Deploy** / Railway akan otomatis build & jalankan `npm start`.
6. Buka tab **Logs** (Deployments → klik deployment aktif → Logs/View Logs).
7. Tunggu beberapa detik, kode pairing 8 digit akan muncul di log, contoh:
   ```
   🔑 KODE PAIRING KAMU: ABCD-1234
   ```
8. Di HP (pakai nomor yang sama dengan `PHONE_NUMBER`), buka WhatsApp:
   - **Pengaturan** → **Perangkat Tertaut** → **Tautkan Perangkat**
   - Pilih **"Tautkan dengan nomor telepon"**
   - Masukkan kode 8 digit dari Logs Railway (cepat, kode hanya berlaku sebentar)
9. Setelah berhasil, log akan menampilkan "✅ YASH BOT berhasil terhubung ke WhatsApp!" dan bot langsung aktif 24 jam selama project Railway berjalan.

> ⚠️ Catatan penting: folder `session/` di Railway **tidak permanen** kecuali kamu menambahkan **Volume** di Railway (Settings → Volumes → mount ke path `/app/session`). Tanpa volume, sesi login akan hilang setiap kali Railway redeploy/restart container, dan kamu harus pairing ulang. Sangat disarankan tambah Volume agar tidak perlu pairing berkali-kali.



**Games:** !tebakkata, !tebaklirik, !quiz, !tebakangka, !suit, !slot, !truth, !dare, !tod, !stop
**Hiburan:** !joke, !fakta, !quote, !pantun, !rate, !jodoh, !hoki
**Sticker:** !s / !sticker, !sw / !stickerw (reply gambar/video)
**Anime:** !anime, !char, !topanime (via Jikan API/MyAnimeList)
**Tools:** !translate, !calc, !cuaca, !lirik
**Grup (admin):** !tagall, !hidetag, !open, !close, !kick, !promote, !demote, !antilink, !welcome, !cekadmin
**Reward:** !poin / !xp, !daily, !rank, !lb

Ketik **!menu** di chat untuk menampilkan daftar lengkap.

## ⚠️ Catatan

- Pastikan bot dijadikan **admin grup** agar fitur kick/promote/demote/open/close/antilink berfungsi.
- Fitur cuaca menggunakan API gratis `wttr.in` (tanpa API key).
- Fitur lirik menggunakan API gratis `lyrics.ovh` — ketik dengan format `artis - judul lagu` untuk hasil lebih akurat.
- Fitur anime/karakter menggunakan API gratis Jikan (MyAnimeList) yang memiliki rate limit, hindari spam request berturut-turut.
- Jalankan dengan PM2 atau screen/tmux di VPS agar bot tetap aktif 24 jam non-stop, contoh:
  ```bash
  npm install -g pm2
  pm2 start index.js --name yash-bot
  pm2 logs yash-bot
  ```
