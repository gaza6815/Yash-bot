const config = require("./config");
const db = require("./database");
const game = require("./gameSession");
const data = require("./staticData");
const helpers = require("./helpers");

const MENU_TEXT = `╔════════════════════╗
🤖  *Y A S H  B O T*  🤖
╚════════════════════╝

> Halo *apa aja*! Aku siap membantumu 24/7
> Gunakan perintah di bawah ini ⬇️

━━━━━━━━━━━━━━━━━━━━
🎮 *G A M E S*
━━━━━━━━━━━━━━━━━━━━
  ◈ *!tebakkata*   → Tebak kata
  ◈ *!tebaklirik*  → Tebak lirik lagu
  ◈ *!quiz*        → Kuis cepat
  ◈ *!tebakangka*  → Tebak angka
  ◈ *!suit* [batu/gunting/kertas]
  ◈ *!slot*        → Mesin slot
  ◈ *!ttt* @lawan  → Tic Tac Toe
  ◈ *!truth* / *!dare* / *!tod*
  ◈ *!stop*        → Hentikan game

━━━━━━━━━━━━━━━━━━━━
😂 *H I B U R A N*
━━━━━━━━━━━━━━━━━━━━
  ◈ *!joke*        → Jokes lucu
  ◈ *!fakta*       → Fakta unik
  ◈ *!quote*       → Quote harian
  ◈ *!pantun*      → Pantun random
  ◈ *!rate* @user  → Rate member
  ◈ *!jodoh* @u1 @u2
  ◈ *!hoki*        → Cek hoki hari ini

━━━━━━━━━━━━━━━━━━━━
🎨 *S T I C K E R*
━━━━━━━━━━━━━━━━━━━━
  ◈ *!s / !sticker*     → Buat sticker
  ◈ *!sw / !stickerw*   → Sticker + watermark

━━━━━━━━━━━━━━━━━━━━
🎌 *A N I M E*
━━━━━━━━━━━━━━━━━━━━
  ◈ *!anime* [judul]    → Info anime
  ◈ *!char* [nama]      → Info karakter
  ◈ *!topanime*         → Top 10 airing

━━━━━━━━━━━━━━━━━━━━
⚙️ *T O O L S*
━━━━━━━━━━━━━━━━━━━━
  ◈ *!translate* [teks] → Terjemahkan
  ◈ *!calc* [ekspresi]  → Kalkulator
  ◈ *!cuaca* [kota]     → Info cuaca
  ◈ *!lirik* [judul]    → Cari lirik lagu

━━━━━━━━━━━━━━━━━━━━
👥 *G R U P*  _(Admin)_
━━━━━━━━━━━━━━━━━━━━
  ◈ *!tagall*      → Tag semua member
  ◈ *!hidetag*     → Tag tersembunyi
  ◈ *!open/close*  → Buka/tutup grup
  ◈ *!kick* @user  → Keluarkan member
  ◈ *!promote* @user → Jadikan admin
  ◈ *!demote* @user  → Cabut admin
  ◈ *!antilink* on/off
  ◈ *!welcome* on/off [pesan]
  ◈ *!cekadmin*    → Daftar admin

━━━━━━━━━━━━━━━━━━━━
🏆 *R E W A R D*
━━━━━━━━━━━━━━━━━━━━
  ◈ *!poin / !xp*  → Lihat poin kamu
  ◈ *!daily*       → Reward harian 🎁
  ◈ *!rank*        → Rank kamu
  ◈ *!lb*          → Leaderboard Top 10

╔════════════════════╗
⚡ _Bot aktif 24 jam non-stop_
╚════════════════════╝`;

async function handleCommand(sock, msg, body) {
  const chatId = msg.key.remoteJid;
  const sender = msg.key.participant || msg.key.remoteJid;
  const isGroup = chatId.endsWith("@g.us");
  const prefix = config.prefix;

  if (!body.startsWith(prefix)) {
    return handleGameAnswer(sock, msg, body);
  }

  const args = body.slice(prefix.length).trim().split(/\s+/);
  const cmd = args.shift().toLowerCase();
  const text = args.join(" ");
  const reply = (t) => sock.sendMessage(chatId, { text: t }, { quoted: msg });

  try {
    switch (cmd) {
      case "menu":
      case "help":
        return reply(MENU_TEXT);

      case "tebakkata": {
        const q = helpers.randomItem(data.tebakKata);
        game.setGame(chatId, { type: "tebakkata", jawaban: q.jawaban });
        return reply(`🔤 *Tebak Kata*\n\nPetunjuk: ${q.soal}\n\nKetik jawabanmu langsung di chat!`);
      }
      case "tebaklirik": {
        const q = helpers.randomItem(data.tebakLirik);
        game.setGame(chatId, { type: "tebaklirik", jawaban: q.jawaban });
        return reply(`🎵 *Tebak Lirik*\n\n"${q.lirik}"\n\nLanjutan liriknya apa? Ketik jawabanmu!`);
      }
      case "quiz": {
        const q = helpers.randomItem(data.quiz);
        game.setGame(chatId, { type: "quiz", jawaban: String(q.jawaban).toLowerCase() });
        return reply(`❓ *Quiz*\n\n${q.soal}\n\nKetik jawabanmu!`);
      }
      case "tebakangka": {
        const target = Math.floor(Math.random() * 50) + 1;
        game.setGame(chatId, { type: "tebakangka", jawaban: target, percobaan: 0 });
        return reply(`🔢 *Tebak Angka*\n\nAku memikirkan angka 1-50. Tebak angkanya!`);
      }
      case "suit": {
        const pilihanUser = args[0]?.toLowerCase();
        const opsi = ["batu", "gunting", "kertas"];
        if (!opsi.includes(pilihanUser)) {
          return reply(`Gunakan: *!suit* batu/gunting/kertas`);
        }
        const pilihanBot = helpers.randomItem(opsi);
        let hasil;
        if (pilihanUser === pilihanBot) hasil = "Seri! 🤝";
        else if (
          (pilihanUser === "batu" && pilihanBot === "gunting") ||
          (pilihanUser === "gunting" && pilihanBot === "kertas") ||
          (pilihanUser === "kertas" && pilihanBot === "batu")
        ) {
          hasil = "Kamu menang! 🎉";
          db.addPoin(sender, 5);
        } else {
          hasil = "Kamu kalah! 😢";
        }
        return reply(`✊✌️✋ *SUIT*\n\nKamu: ${pilihanUser}\nBot: ${pilihanBot}\n\n${hasil}`);
      }
      case "slot": {
        const simbol = ["🍒", "🍋", "🍇", "🍉", "⭐", "💎", "7️⃣"];
        const hasil = [helpers.randomItem(simbol), helpers.randomItem(simbol), helpers.randomItem(simbol)];
        const menang = hasil[0] === hasil[1] && hasil[1] === hasil[2];
        if (menang) db.addPoin(sender, 20);
        return reply(
          `🎰 *SLOT MACHINE*\n\n[ ${hasil.join(" | ")} ]\n\n${
            menang ? "🎉 JACKPOT! +20 poin" : "Belum beruntung, coba lagi!"
          }`
        );
      }
      case "ttt": {
        return reply("🎮 Fitur Tic Tac Toe segera hadir di update berikutnya!");
      }
      case "truth": {
        const truths = [
          "Apa hal paling memalukan yang pernah kamu lakukan?",
          "Siapa crush pertamamu?",
          "Apa rahasia yang belum pernah kamu ceritakan ke siapapun?",
        ];
        return reply(`🗣️ *Truth*\n\n${helpers.randomItem(truths)}`);
      }
      case "dare": {
        const dares = [
          "Kirim voice note nyanyi 15 detik!",
          "Ganti foto profil jadi meme selama 1 jam.",
          "Chat orang random di kontakmu 'halo kangen'.",
        ];
        return reply(`🔥 *Dare*\n\n${helpers.randomItem(dares)}`);
      }
      case "tod": {
        const isTruth = Math.random() > 0.5;
        return reply(
          isTruth
            ? `🗣️ *Truth*\n\nApa hal paling konyol yang pernah kamu lakukan?`
            : `🔥 *Dare*\n\nKirim selfie paling jelek yang kamu punya!`
        );
      }
      case "stop": {
        if (game.hasGame(chatId)) {
          game.clearGame(chatId);
          return reply("🛑 Game dihentikan.");
        }
        return reply("Tidak ada game yang sedang berjalan.");
      }

      case "joke":
        return reply(`😂 *Joke*\n\n${helpers.randomItem(data.jokes)}`);
      case "fakta":
        return reply(`💡 *Fakta Unik*\n\n${helpers.randomItem(data.facts)}`);
      case "quote":
        return reply(`✨ *Quote Harian*\n\n"${helpers.randomItem(data.quotes)}"`);
      case "pantun":
        return reply(`📜 *Pantun*\n\n${helpers.randomItem(data.pantun)}`);
      case "rate": {
        const mentioned = helpers.getMentioned(msg);
        const target = mentioned[0] || sender;
        const persen = Math.floor(Math.random() * 101);
        return sock.sendMessage(
          chatId,
          { text: `⭐ Rate untuk @${target.split("@")[0]}: *${persen}%*`, mentions: [target] },
          { quoted: msg }
        );
      }
      case "jodoh": {
        const mentioned = helpers.getMentioned(msg);
        if (mentioned.length < 2) return reply("Tag 2 orang ya! Contoh: !jodoh @u1 @u2");
        const persen = Math.floor(Math.random() * 101);
        return sock.sendMessage(
          chatId,
          {
            text: `💕 *Cek Jodoh*\n\n@${mentioned[0].split("@")[0]} + @${mentioned[1].split("@")[0]}\nKecocokan: *${persen}%*`,
            mentions: mentioned,
          },
          { quoted: msg }
        );
      }
      case "hoki": {
        const hokis = ["Sangat Beruntung 🍀", "Cukup Baik 🙂", "Biasa Saja 😐", "Hati-hati Hari Ini ⚠️", "Sial 😬"];
        return reply(`🔮 *Hoki Hari Ini*\n\n${helpers.randomItem(hokis)}`);
      }

      case "s":
      case "sticker":
      case "sw":
      case "stickerw":
        return require("./stickerHandler")(sock, msg, chatId, cmd === "sw" || cmd === "stickerw");

      case "anime": {
        if (!text) return reply("Masukkan judul anime! Contoh: !anime naruto");
        const a = await helpers.getAnime(text);
        return reply(
          `🎌 *${a.title}*\n\nTipe: ${a.type}\nEpisode: ${a.episodes || "?"}\nStatus: ${a.status}\nSkor: ${a.score}\n\n${a.synopsis}\n\n🔗 ${a.url}`
        );
      }
      case "char": {
        if (!text) return reply("Masukkan nama karakter! Contoh: !char luffy");
        const c = await helpers.getCharacter(text);
        return reply(`🎭 *${c.name}*\n\nNama lain: ${c.nicknames}\nFavorit: ${c.favorites}\n\n${c.about}\n\n🔗 ${c.url}`);
      }
      case "topanime": {
        const top = await helpers.getTopAnime();
        return reply(`🏆 *Top 10 Anime Airing*\n\n${top}`);
      }

      case "translate": {
        if (!text) return reply("Masukkan teks! Contoh: !translate hello world");
        const hasil = await helpers.translateText(text, "id");
        return reply(`🌐 *Translate*\n\n${hasil}`);
      }
      case "calc": {
        if (!text) return reply("Masukkan ekspresi! Contoh: !calc 5*(3+2)");
        const hasil = helpers.safeCalc(text);
        return reply(`🧮 *Kalkulator*\n\n${text} = ${hasil}`);
      }
      case "cuaca": {
        if (!text) return reply("Masukkan nama kota! Contoh: !cuaca jakarta");
        const w = await helpers.getWeather(text);
        return reply(
          `⛅ *Cuaca ${text}*\n\nSuhu: ${w.suhu}°C (terasa ${w.terasa}°C)\nKondisi: ${w.kondisi}\nKelembapan: ${w.kelembapan}%\nAngin: ${w.angin} km/jam`
        );
      }
      case "lirik": {
        if (!text) return reply("Masukkan judul lagu! Contoh: !lirik artis - judul");
        const lirik = await helpers.getLyrics(text);
        return reply(`🎶 *Lirik*\n\n${lirik.slice(0, 1500)}`);
      }

      case "tagall":
      case "hidetag": {
        if (!isGroup) return reply("Perintah ini hanya untuk grup.");
        const metadata = await sock.groupMetadata(chatId);
        const participants = metadata.participants.map((p) => p.id);
        const teks =
          cmd === "tagall" ? participants.map((p) => `@${p.split("@")[0]}`).join(" ") : text || "📢 Pesan untuk semua member";
        return sock.sendMessage(chatId, { text: teks, mentions: participants }, { quoted: msg });
      }
      case "open":
      case "close": {
        if (!isGroup) return reply("Perintah ini hanya untuk grup.");
        if (!(await helpers.isGroupAdmin(sock, chatId, sender))) return reply("Hanya admin yang bisa pakai perintah ini.");
        if (!(await helpers.isBotAdmin(sock, chatId))) return reply("Bot harus jadi admin dulu untuk mengubah setting grup.");
        await sock.groupSettingUpdate(chatId, cmd === "open" ? "not_announcement" : "announcement");
        db.updateGroup(chatId, { isOpen: cmd === "open" });
        return reply(cmd === "open" ? "🔓 Grup dibuka, semua member bisa chat." : "🔒 Grup ditutup, hanya admin yang bisa chat.");
      }
      case "kick": {
        if (!isGroup) return reply("Perintah ini hanya untuk grup.");
        if (!(await helpers.isGroupAdmin(sock, chatId, sender))) return reply("Hanya admin yang bisa pakai perintah ini.");
        if (!(await helpers.isBotAdmin(sock, chatId))) return reply("Bot harus jadi admin dulu.");
        const mentioned = helpers.getMentioned(msg);
        if (!mentioned.length) return reply("Tag member yang mau dikeluarkan!");
        await sock.groupParticipantsUpdate(chatId, mentioned, "remove");
        return reply("✅ Member berhasil dikeluarkan.");
      }
      case "promote": {
        if (!isGroup) return reply("Perintah ini hanya untuk grup.");
        if (!(await helpers.isGroupAdmin(sock, chatId, sender))) return reply("Hanya admin yang bisa pakai perintah ini.");
        if (!(await helpers.isBotAdmin(sock, chatId))) return reply("Bot harus jadi admin dulu.");
        const mentioned = helpers.getMentioned(msg);
        if (!mentioned.length) return reply("Tag member yang mau dijadikan admin!");
        await sock.groupParticipantsUpdate(chatId, mentioned, "promote");
        return reply("✅ Member berhasil dijadikan admin.");
      }
      case "demote": {
        if (!isGroup) return reply("Perintah ini hanya untuk grup.");
        if (!(await helpers.isGroupAdmin(sock, chatId, sender))) return reply("Hanya admin yang bisa pakai perintah ini.");
        if (!(await helpers.isBotAdmin(sock, chatId))) return reply("Bot harus jadi admin dulu.");
        const mentioned = helpers.getMentioned(msg);
        if (!mentioned.length) return reply("Tag admin yang mau dicabut!");
        await sock.groupParticipantsUpdate(chatId, mentioned, "demote");
        return reply("✅ Admin berhasil dicabut.");
      }
      case "antilink": {
        if (!isGroup) return reply("Perintah ini hanya untuk grup.");
        if (!(await helpers.isGroupAdmin(sock, chatId, sender))) return reply("Hanya admin yang bisa pakai perintah ini.");
        const status = args[0]?.toLowerCase();
        if (!["on", "off"].includes(status)) return reply("Gunakan: !antilink on/off");
        db.updateGroup(chatId, { antilink: status === "on" });
        return reply(`🔗 Antilink ${status === "on" ? "diaktifkan" : "dinonaktifkan"}.`);
      }
      case "welcome": {
        if (!isGroup) return reply("Perintah ini hanya untuk grup.");
        if (!(await helpers.isGroupAdmin(sock, chatId, sender))) return reply("Hanya admin yang bisa pakai perintah ini.");
        const status = args[0]?.toLowerCase();
        if (!["on", "off"].includes(status)) return reply("Gunakan: !welcome on/off [pesan]");
        const pesan = args.slice(1).join(" ");
        db.updateGroup(chatId, { welcome: status === "on", ...(pesan ? { welcomeMsg: pesan } : {}) });
        return reply(`👋 Welcome message ${status === "on" ? "diaktifkan" : "dinonaktifkan"}.`);
      }
      case "cekadmin": {
        if (!isGroup) return reply("Perintah ini hanya untuk grup.");
        const metadata = await sock.groupMetadata(chatId);
        const admins = metadata.participants.filter((p) => p.admin);
        const list = admins.map((a) => `• @${a.id.split("@")[0]}`).join("\n");
        return sock.sendMessage(
          chatId,
          { text: `👑 *Daftar Admin Grup*\n\n${list}`, mentions: admins.map((a) => a.id) },
          { quoted: msg }
        );
      }

      case "poin":
      case "xp": {
        const u = db.getUser(sender);
        return reply(`🏆 Poin kamu: *${u.poin}*\nXP kamu: *${u.xp}*`);
      }
      case "daily": {
        const u = db.getUser(sender);
        const now = Date.now();
        const oneDay = 24 * 60 * 60 * 1000;
        if (now - u.lastDaily < oneDay) {
          const sisa = oneDay - (now - u.lastDaily);
          const jam = Math.floor(sisa / 3600000);
          const menit = Math.floor((sisa % 3600000) / 60000);
          return reply(`⏳ Kamu sudah klaim daily hari ini. Coba lagi dalam ${jam} jam ${menit} menit.`);
        }
        db.addPoin(sender, config.dailyReward);
        db.updateUser(sender, { lastDaily: now });
        return reply(`🎁 Daily reward berhasil diklaim! +${config.dailyReward} poin`);
      }
      case "rank": {
        const rank = db.getRank(sender);
        const u = db.getUser(sender);
        return reply(`📊 Rank kamu: *#${rank}*\nPoin: ${u.poin}`);
      }
      case "lb": {
        const top = db.getLeaderboard(10);
        if (!top.length) return reply("Leaderboard masih kosong.");
        const list = top.map(([jid, u], i) => `${i + 1}. @${jid.split("@")[0]} - ${u.poin} poin`).join("\n");
        return sock.sendMessage(
          chatId,
          { text: `🏆 *Leaderboard Top 10*\n\n${list}`, mentions: top.map(([jid]) => jid) },
          { quoted: msg }
        );
      }

      default:
        return;
    }
  } catch (err) {
    console.error("Command error:", err);
    return reply(`❌ Terjadi kesalahan: ${err.message}`);
  }
}

async function handleGameAnswer(sock, msg, body) {
  const chatId = msg.key.remoteJid;
  const sender = msg.key.participant || msg.key.remoteJid;
  const reply = (t) => sock.sendMessage(chatId, { text: t }, { quoted: msg });

  if (!game.hasGame(chatId)) return;
  const g = game.getGame(chatId);
  const jawabanUser = body.trim().toLowerCase();

  if (g.type === "tebakangka") {
    const tebakan = parseInt(jawabanUser);
    if (isNaN(tebakan)) return;
    g.percobaan++;
    if (tebakan === g.jawaban) {
      db.addPoin(sender, 10);
      game.clearGame(chatId);
      return reply(`🎉 Benar! Angkanya adalah ${g.jawaban}. (${g.percobaan} percobaan) +10 poin`);
    } else if (tebakan < g.jawaban) {
      return reply("📈 Lebih besar lagi!");
    } else {
      return reply("📉 Lebih kecil lagi!");
    }
  }

  if (["tebakkata", "tebaklirik", "quiz"].includes(g.type)) {
    if (jawabanUser === g.jawaban.toLowerCase()) {
      db.addPoin(sender, 10);
      game.clearGame(chatId);
      return reply(`🎉 Benar! Jawabannya: ${g.jawaban}. +10 poin`);
    }
  }
}

module.exports = { handleCommand, MENU_TEXT };
