module.exports = {
  botName: "YASH BOT",
  // Nomor owner (62xxxxxxxxxx) tanpa + dan tanpa spasi
  ownerNumber: "628123456789",
  // Prefix command
  prefix: "!",
  // Sesi auth Baileys disimpan di folder ini
  sessionDir: "./session",
  // Daily reward amount
  dailyReward: 50,
};
