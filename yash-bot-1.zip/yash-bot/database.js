const fs = require("fs");
const path = require("path");

const DB_DIR = path.join(__dirname, "data");
const FILES = {
  users: path.join(DB_DIR, "users.json"),
  groups: path.join(DB_DIR, "groups.json"),
};

if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
for (const f of Object.values(FILES)) {
  if (!fs.existsSync(f)) fs.writeFileSync(f, "{}");
}

function read(file) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf-8"));
  } catch {
    return {};
  }
}

function write(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// ===== USERS (poin / xp / daily) =====
function getUser(jid) {
  const users = read(FILES.users);
  if (!users[jid]) {
    users[jid] = { poin: 0, xp: 0, lastDaily: 0 };
    write(FILES.users, users);
  }
  return users[jid];
}

function updateUser(jid, patch) {
  const users = read(FILES.users);
  if (!users[jid]) users[jid] = { poin: 0, xp: 0, lastDaily: 0 };
  users[jid] = { ...users[jid], ...patch };
  write(FILES.users, users);
  return users[jid];
}

function addPoin(jid, amount) {
  const users = read(FILES.users);
  if (!users[jid]) users[jid] = { poin: 0, xp: 0, lastDaily: 0 };
  users[jid].poin += amount;
  users[jid].xp += amount;
  write(FILES.users, users);
  return users[jid];
}

function getLeaderboard(limit = 10) {
  const users = read(FILES.users);
  return Object.entries(users)
    .sort((a, b) => b[1].poin - a[1].poin)
    .slice(0, limit);
}

function getRank(jid) {
  const users = read(FILES.users);
  const sorted = Object.entries(users).sort((a, b) => b[1].poin - a[1].poin);
  const idx = sorted.findIndex(([id]) => id === jid);
  return idx === -1 ? sorted.length + 1 : idx + 1;
}

// ===== GROUPS (settings: antilink, welcome, isOpen) =====
function getGroup(gid) {
  const groups = read(FILES.groups);
  if (!groups[gid]) {
    groups[gid] = {
      antilink: false,
      welcome: false,
      welcomeMsg: "Selamat datang @user di grup ini!",
      isOpen: true,
    };
    write(FILES.groups, groups);
  }
  return groups[gid];
}

function updateGroup(gid, patch) {
  const groups = read(FILES.groups);
  if (!groups[gid]) groups[gid] = getGroup(gid);
  groups[gid] = { ...groups[gid], ...patch };
  write(FILES.groups, groups);
  return groups[gid];
}

module.exports = {
  getUser,
  updateUser,
  addPoin,
  getLeaderboard,
  getRank,
  getGroup,
  updateGroup,
};
