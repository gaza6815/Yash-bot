// Menyimpan state game yang sedang berjalan per-chat (in-memory, reset saat bot restart)
const sessions = new Map();

function setGame(chatId, data) {
  sessions.set(chatId, data);
}

function getGame(chatId) {
  return sessions.get(chatId);
}

function clearGame(chatId) {
  sessions.delete(chatId);
}

function hasGame(chatId) {
  return sessions.has(chatId);
}

module.exports = { setGame, getGame, clearGame, hasGame };
