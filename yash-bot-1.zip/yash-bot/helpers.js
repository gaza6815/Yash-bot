const fetch = require("node-fetch");

function safeCalc(expr) {
  // hanya izinkan angka, operator dasar, kurung, titik, spasi
  if (!/^[0-9+\-*/().\s%]+$/.test(expr)) {
    throw new Error("Ekspresi tidak valid");
  }
  // eslint-disable-next-line no-new-func
  return Function(`"use strict"; return (${expr})`)();
}

async function isGroupAdmin(sock, groupId, userJid) {
  try {
    const metadata = await sock.groupMetadata(groupId);
    const participant = metadata.participants.find((p) => p.id === userJid);
    return participant?.admin === "admin" || participant?.admin === "superadmin";
  } catch {
    return false;
  }
}

async function isBotAdmin(sock, groupId) {
  try {
    const metadata = await sock.groupMetadata(groupId);
    const botId = sock.user.id.split(":")[0] + "@s.whatsapp.net";
    const participant = metadata.participants.find((p) => p.id.split(":")[0] + "@s.whatsapp.net" === botId);
    return participant?.admin === "admin" || participant?.admin === "superadmin";
  } catch {
    return false;
  }
}

function getMentioned(msg) {
  return msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
}

function randomItem(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

async function translateText(text, target = "id") {
  const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(
    text
  )}&langpair=en|${target}`;
  const res = await fetch(url);
  const data = await res.json();
  return data?.responseData?.translatedText || "Gagal menerjemahkan.";
}

async function getWeather(city) {
  const url = `https://wttr.in/${encodeURIComponent(city)}?format=j1`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("Kota tidak ditemukan");
  const data = await res.json();
  const cur = data.current_condition[0];
  return {
    suhu: cur.temp_C,
    terasa: cur.FeelsLikeC,
    kondisi: cur.weatherDesc[0].value,
    kelembapan: cur.humidity,
    angin: cur.windspeedKmph,
  };
}

async function getLyrics(title) {
  // format "artis - judul" lebih akurat, tapi fallback pakai judul saja
  let artist = "";
  let song = title;
  if (title.includes("-")) {
    [artist, song] = title.split("-").map((s) => s.trim());
  }
  const url = `https://api.lyrics.ovh/v1/${encodeURIComponent(artist || "")}/${encodeURIComponent(
    song
  )}`;
  const res = await fetch(url);
  const data = await res.json();
  if (!data.lyrics) throw new Error("Lirik tidak ditemukan");
  return data.lyrics;
}

async function getAnime(title) {
  const url = `https://api.jikan.moe/v4/anime?q=${encodeURIComponent(title)}&limit=1`;
  const res = await fetch(url);
  const data = await res.json();
  if (!data.data || data.data.length === 0) throw new Error("Anime tidak ditemukan");
  const a = data.data[0];
  return {
    title: a.title,
    type: a.type,
    episodes: a.episodes,
    status: a.status,
    score: a.score,
    synopsis: a.synopsis?.slice(0, 500) + "...",
    url: a.url,
  };
}

async function getCharacter(name) {
  const url = `https://api.jikan.moe/v4/characters?q=${encodeURIComponent(name)}&limit=1`;
  const res = await fetch(url);
  const data = await res.json();
  if (!data.data || data.data.length === 0) throw new Error("Karakter tidak ditemukan");
  const c = data.data[0];
  return {
    name: c.name,
    nicknames: c.nicknames?.join(", ") || "-",
    favorites: c.favorites,
    about: c.about?.slice(0, 500) + "...",
    url: c.url,
  };
}

async function getTopAnime() {
  const url = `https://api.jikan.moe/v4/top/anime?filter=airing&limit=10`;
  const res = await fetch(url);
  const data = await res.json();
  return data.data.map((a, i) => `${i + 1}. ${a.title} (⭐ ${a.score})`).join("\n");
}

module.exports = {
  safeCalc,
  isGroupAdmin,
  isBotAdmin,
  getMentioned,
  randomItem,
  translateText,
  getWeather,
  getLyrics,
  getAnime,
  getCharacter,
  getTopAnime,
};
