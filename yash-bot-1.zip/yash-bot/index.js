const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  Browsers,
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const readline = require("readline");
const fs = require("fs");

const config = require("./config");
const { handleCommand } = require("./commandHandler");
const { handleAntilink, handleGroupParticipantsUpdate } = require("./automod");

// ====== Deteksi mode: server (Railway, dll) vs lokal interaktif ======
// Jika ada environment variable PHONE_NUMBER, bot jalan di mode "server"
// (otomatis minta pairing code tanpa perlu ketik manual di terminal).
const isServerMode = !!process.env.PHONE_NUMBER;

// ====== Util tanya input dari terminal (mode lokal saja) ======
let rl;
const question = (q) => {
  if (isServerMode) return Promise.resolve(process.env.PHONE_NUMBER);
  if (!rl) rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => rl.question(q, resolve));
};

async function startBot() {
  if (!fs.existsSync(config.sessionDir)) fs.mkdirSync(config.sessionDir, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(config.sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  // Cek apakah sudah pernah login (sudah ada creds)
  const isRegistered = state.creds.registered;

  // Gunakan METODE PAIRING CODE, bukan QR, jika belum login
  const usePairingCode = !isRegistered;

  const sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: false, // QR dimatikan, kita pakai pairing code
    logger: pino({ level: "silent" }),
    browser: Browsers.ubuntu("Chrome"),
    syncFullHistory: false,
  });

  // ====== PAIRING CODE FLOW ======
  if (usePairingCode) {
    if (isServerMode) {
      console.log("🌐 Mode SERVER terdeteksi (PHONE_NUMBER env var ditemukan).");
    } else {
      console.log("💻 Mode LOKAL terdeteksi, akan minta input nomor di terminal.");
    }

    let phoneNumber = await question(
      "\n📱 Masukkan nomor WhatsApp bot (format: 628xxxxxxxxxx, tanpa + dan tanpa spasi): "
    );
    phoneNumber = (phoneNumber || "").replace(/[^0-9]/g, "");

    if (!phoneNumber) {
      console.error("❌ Nomor WhatsApp tidak ditemukan. Set environment variable PHONE_NUMBER di Railway, lalu redeploy.");
      return;
    }

    // beri jeda sedikit agar socket siap sebelum minta kode
    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(phoneNumber);
        const formatted = code?.match(/.{1,4}/g)?.join("-") || code;
        console.log("\n========================================");
        console.log(`🔑 KODE PAIRING KAMU: ${formatted}`);
        console.log("========================================");
        console.log("Cara pakai:");
        console.log("1. Buka WhatsApp di HP");
        console.log("2. Pengaturan > Perangkat Tertaut > Tautkan Perangkat");
        console.log("3. Pilih 'Tautkan dengan nomor telepon' lalu masukkan kode di atas");
        console.log("⏳ Kode ini hanya berlaku sebentar, segera masukkan di WhatsApp!");
        console.log("========================================\n");
      } catch (err) {
        console.error("Gagal membuat pairing code:", err);
      }
    }, 3000);
  }

  // ====== EVENT: connection update ======
  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
      console.log("Koneksi terputus.", statusCode, "Reconnect:", shouldReconnect);
      if (shouldReconnect) {
        startBot();
      } else {
        console.log("❌ Sesi logout. Hapus folder session lalu jalankan ulang untuk pairing baru.");
      }
    } else if (connection === "open") {
      console.log(`✅ ${config.botName} berhasil terhubung ke WhatsApp!`);
      if (rl) rl.close();
    }
  });

  // ====== EVENT: simpan kredensial ======
  sock.ev.on("creds.update", saveCreds);

  // ====== EVENT: pesan masuk ======
  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const body =
      msg.message.conversation ||
      msg.message.extendedTextMessage?.text ||
      msg.message.imageMessage?.caption ||
      msg.message.videoMessage?.caption ||
      "";

    if (!body) return;

    try {
      // cek antilink dulu sebelum proses command
      const deleted = await handleAntilink(sock, msg, body);
      if (deleted) return;

      await handleCommand(sock, msg, body.trim());
    } catch (err) {
      console.error("Error proses pesan:", err);
    }
  });

  // ====== EVENT: member masuk/keluar grup (welcome/leave) ======
  sock.ev.on("group-participants.update", (update) => {
    handleGroupParticipantsUpdate(sock, update);
  });

  return sock;
}

startBot().catch((err) => console.error("Gagal start bot:", err));
