const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const sharp = require("sharp");
const webp = require("node-webpmux");
const fs = require("fs");
const os = require("os");
const path = require("path");

module.exports = async function stickerHandler(sock, msg, chatId, withWatermark) {
  const reply = (t) => sock.sendMessage(chatId, { text: t }, { quoted: msg });

  const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  const target =
    msg.message?.imageMessage || msg.message?.videoMessage
      ? msg
      : quoted?.imageMessage || quoted?.videoMessage
      ? {
          key: msg.message.extendedTextMessage.contextInfo.stanzaId
            ? msg.key
            : msg.key,
          message: quoted,
        }
      : null;

  if (!target) {
    return reply("Kirim/reply gambar atau video pendek dengan caption *!s* untuk membuat sticker.");
  }

  try {
    const buffer = await downloadMediaMessage(target, "buffer", {});
    const tmpInput = path.join(os.tmpdir(), `in_${Date.now()}.png`);
    const tmpWebp = path.join(os.tmpdir(), `out_${Date.now()}.webp`);

    await sharp(buffer)
      .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
      .toFormat("webp")
      .toFile(tmpWebp);

    let finalBuffer = fs.readFileSync(tmpWebp);

    if (withWatermark) {
      const img = new webp.Image();
      await img.load(tmpWebp);
      const json = {
        "sticker-pack-id": "yashbot",
        "sticker-pack-name": "YASH BOT",
        "sticker-pack-publisher": "YASH BOT",
      };
      const exifAttr = Buffer.from([
        0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57,
        0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
      ]);
      const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8");
      const exif = Buffer.concat([exifAttr, jsonBuff]);
      exif.writeUIntLE(jsonBuff.length, 14, 4);
      img.exif = exif;
      finalBuffer = await img.save(null);
    }

    await sock.sendMessage(chatId, { sticker: finalBuffer }, { quoted: msg });

    fs.unlinkSync(tmpWebp);
  } catch (err) {
    console.error("Sticker error:", err);
    return reply("❌ Gagal membuat sticker. Pastikan media yang dikirim valid (gambar/video pendek).");
  }
};
